clear; clc; close all;

% Modelado del robot
[robot, p_fun, J_fun, T_fun, a2_val, T2_offset_val, T3_offset_val] = model();
robot.plot([0 0 0 0 0 0]);

% Cinemática
[Q_des, dQ_des, ddQ_des, t, P] = zinematika(robot, p_fun, J_fun, T_fun);
if isempty(Q_des)
    disp('No se pudo planificar una trayectoria válida.');
    return;
end

% Control dinámico
grav = [0; 0; -9.81];

[tau_hist, q_hist, dq_hist] = din_control(robot, Q_des, dQ_des, ddQ_des, t, grav);

% Algunas gráficas rápidas
%{
figure;
plot(t(1:end-2), tau_hist, 'LineWidth',1.2);
xlabel('Tiempo [s]'); ylabel('Torque [Nm]');
title('Torques articulares (control dinámico)');
legend('tau1','tau2','tau3','tau4','tau5','tau6','Location','bestoutside');

figure;
plot(t, rad2deg(Q_des), '--', 'LineWidth',1.0); hold on;
plot(t, rad2deg(q_hist), '-', 'LineWidth',1.5);
xlabel('Tiempo [s]'); ylabel('Ángulo [deg]');
title('Trayectoria deseada vs. ejecutada');
legend('q1_d','q2_d','q3_d','q4_d','q5_d','q6_d','Location','bestoutside');
%}