function [tau_hist, q_hist, dq_hist] = din_control(robot, ...
                                                   Q_des, dQ_des, ddQ_des, t, grav)
% DIN_CONTROL
%   Control dinámico articular con PID + feedforward (computed torque)
%
% Entradas:
%   robot   : objeto SerialLink (con dinámica cargada)
%   Q_des   : posiciones deseadas [N x 6]
%   dQ_des  : velocidades deseadas [N-1 x 6]
%   ddQ_des : aceleraciones deseadas [N-2 x 6]
%   t       : vector de tiempo [1 x N]
%   grav    : vector gravedad [3x1], p.ej. [0;0;-9.81]
%
% Salidas:
%   tau_hist : torques aplicados [N-2 x 6]
%   q_hist   : posiciones simuladas [N x 6]
%   dq_hist  : velocidades simuladas [N x 6]

    %% ================================
    %  Parámetros del controlador PID
    % ================================
    % Ajusta estos valores a mano
    Kp = diag([150 150 120 80 50 30]);   % proporcional
    Kd = diag([20  20  15  10  7  5]);   % derivativo
    Ki = diag([5   5   4   3   2  1]);   % integral (cuidado con integrador)

    % Límites de torque (ejemplo, pon aquí los del fabricante)
    tau_max = [8.4 8.4 4.2 1.5 1.5 1.5];  % [Nm]
    tau_min = -tau_max;

    %% ================================
    %  Inicialización
    % ================================
    N  = size(Q_des,1);      % número de muestras
    dof = size(Q_des,2);     % nº articulaciones (6)

    dt = t(2) - t(1);

    % Estados simulados (inicializamos con la primera muestra de la referencia)
    q  = Q_des(1,:).';
    dq = zeros(dof,1);

    % Históricos
    q_hist   = zeros(N,   dof);
    dq_hist  = zeros(N,   dof);
    tau_hist = zeros(N-2, dof);

    q_hist(1,:)  = q.';
    dq_hist(1,:) = dq.';

    % Error integral
    int_e = zeros(dof,1);

    %% ================================
    %  Bucle de control en el tiempo
    % ================================
    for k = 1:(N-2)

        % Referencias en el instante k
        q_d   = Q_des(k,:).';       % [6x1]
        dq_d  = dQ_des(k,:).';      % [6x1]
        ddq_d = ddQ_des(k,:).';     % [6x1]

        % Errores
        e   = q_d   - q;
        de  = dq_d  - dq;
        int_e = int_e + e*dt;       % integración simple

        % Aceleración "comandada" por el PID
        ddq_cmd = ddq_d + Kp*e + Kd*de + Ki*int_e;

        % DEBUG: inspeccionar tamaños y valores antes de llamar a rne
        fprintf('\nIteración k = %d\n', k);
        disp('size(q.'')     = '), disp(size(q.'))
        disp('size(dq.'')    = '), disp(size(dq.'))
        disp('size(ddq_cmd.'') = '), disp(size(ddq_cmd.'))
        disp('size(grav)     = '), disp(size(grav))
        disp('q.'');'), disp(q.')
        disp('dq.'');'), disp(dq.')
        disp('ddq_cmd.'');'), disp(ddq_cmd.')

        % Feedforward dinámico: torque a partir de la dinámica inversa
        tau = robot.rne(q.', dq.', ddq_cmd.', grav);   % rne espera filas

        % Saturación de torque
        tau = max(min(tau, tau_max), tau_min);

        % Dinámica directa simplificada: integramos ddq_cmd
        % dq = dq + ddq_cmd*dt;
        % q  = q  + dq*dt;

        % Dinámica real del robot
        ddq_real = robot.accel(q.', dq.', tau)  % devuelve fila
        
        ddq_real = ddq_real.';  % convertir a columna
        dq 
        dt 
        q 
        % Integración
        dq = dq + ddq_real * dt;
        q  = q  + dq * dt;

        tau
        q
        dq
        % Guardar históricos
        tau_hist(k,:) = tau;
        q_hist(k+1,:) = q.';
        dq_hist(k+1,:) = dq.';
    end

end
