function [Q_des, dQ_des, ddQ_des, t, P] = zinematika(robot, p_fun, J_fun, T_fun)

    %% ================================
    %  Límites articulares (en rad)
    % ================================
    q_min = robot.qlim(:,1);
    q_max = robot.qlim(:,2);
    q_mid = (q_min + q_max)/2;

    %% ================================
    %  Entrada del usuario
    % ================================
    dlg = inputdlg( ...
        {'Articulaciones actuales [q1 q2 q3 q4 q5 q6] en grados (matemático):', ...
         'Posición final del efector [x y z] en mm:', ...
         'Duración nominal de la trayectoria [s]:'}, ...
        'Entrada de movimiento', [1 70], {'0 0 0 0 0 0', '350 150 250', '5'});

    if isempty(dlg)
        q0_deg   = input('Introduce [q1 q2 q3 q4 q5 q6] en grados (matemático): ');
        p_goal_mm = input('Introduce [x y z] en mm para la posición final del efector: ');
        T         = input('Introduce la duración nominal de la trayectoria [s]: ');
    else
        q0_deg    = str2num(dlg{1});
        p_goal_mm = str2num(dlg{2}); 
        T         = str2double(dlg{3});
    end

    assert(numel(q0_deg)==6);
    assert(numel(p_goal_mm)==3);

    q_init   = deg2rad(q0_deg(:));     % rad
    p_goal_m = p_goal_mm(:) / 1000;    % mm → m

    %% ================================
    %  Pose inicial cartesiana
    % ================================
    T_init = T_fun(q_init(1), q_init(2), q_init(3), ...
                   q_init(4), q_init(5), q_init(6));
    p_init_m = T_init(1:3,4); %#ok<NASGU>

    %% ================================
    %  Verificación de alcanzabilidad
    % ================================
    reach_max_m = 0.7; % 700 mm
    if norm(p_goal_m) > reach_max_m
        fprintf('Objetivo fuera del alcance -> NO realizable\n');
        Q_des = []; dQ_des = []; ddQ_des = []; t = []; P = [];
        return
    end

    %% ================================
    %  IK numérica (posición)
    % ================================
    tol     = 1e-6; 
    maxIter = 80; 
    K       = 0.005;

    q_goal = newtonIK(p_goal_m, q_init, p_fun, J_fun, ...
                      q_min, q_max, q_mid, K, tol, maxIter);

    %% ================================
    %  Trayectoria quíntica + IPTP
    % ================================
    n = 300; 
    t = linspace(0, T, n);

    % ✅ SIN deg2rad aquí (ya está todo en rad)
    Q_des = quinticTraj(q_init.', q_goal.', T, t);

    vel_max = deg2rad([180 180 180 180 180 180]);
    acc_max = deg2rad([1500 1500 1500 1500 1500 1500]);

    [Q_des, t, T_scaled] = iptp_scale_time(Q_des, t, vel_max, acc_max); %#ok<ASGLU>

    dt      = t(2) - t(1);
    dQ_des  = diff(Q_des) / dt;
    ddQ_des = diff(dQ_des) / dt;

    %% ================================
    %  Trayectoria cartesiana del efector
    % ================================
    P = zeros(numel(t), 3);
    for k = 1:numel(t)
        Tnow   = T_fun(Q_des(k,1), Q_des(k,2), Q_des(k,3), ...
                       Q_des(k,4), Q_des(k,5), Q_des(k,6));
        p_m    = Tnow(1:3,4);     % metros
        P(k,:) = (p_m * 1000).';  % mm para graficar
    end

    %% ================================
    %  Gráficas rápidas
    % ================================
    figure;
    plot(t, rad2deg(Q_des), 'LineWidth',1.2);
    xlabel('Tiempo [s]'); ylabel('Ángulo [deg]');
    title('Trayectoria articular deseada');
    legend('q1','q2','q3','q4','q5','q6','Location','bestoutside');

    figure;
    plot(t(1:end-1), rad2deg(dQ_des), 'LineWidth',1.2);
    xlabel('Tiempo [s]'); ylabel('Velocidad [deg/s]');
    title('Velocidades articulares deseadas');

    figure;
    plot(t(1:end-2), rad2deg(ddQ_des), 'LineWidth',1.2);
    xlabel('Tiempo [s]'); ylabel('Aceleración [deg/s^2]');
    title('Aceleraciones articulares deseadas');

    figure;
    plot3(P(:,1), P(:,2), P(:,3), 'LineWidth',1.5);
    grid on; xlabel('X [mm]'); ylabel('Y [mm]'); zlabel('Z [mm]');
    title('Trayectoria cartesiana deseada');

end

%% ================================
%  IK numérica
% ================================
function q_sol = newtonIK(p_d_m, q_seed, p_fun, J_fun, ...
                          q_min, q_max, q_mid, K, tol, maxIter)

    qk = q_seed(:);
    for it = 1:maxIter %#ok<NASGU>
        p_now_m = p_fun(qk(1), qk(2), qk(3), qk(4), qk(5), qk(6));
        J_now   = J_fun(qk(1), qk(2), qk(3), qk(4), qk(5), qk(6));

        e = p_d_m - p_now_m;
        if norm(e) < tol, break; end

        gradH = 2 * (qk - q_mid) ./ ((q_max - q_min).^2);
        dq    = pinv(J_now) * e - K * gradH;

        qk = qk + dq;
    end
    q_sol = qk;
end

%% ================================
%  Quintic
% ================================
function Q = quinticTraj(q0, qf, T, t)
    n = numel(t); 
    Q = zeros(n, numel(q0));
    for i = 1:numel(q0)
        a0 = q0(i); a1 = 0; a2 = 0;
        a3 = 10*(qf(i)-q0(i))/T^3;
        a4 = -15*(qf(i)-q0(i))/T^4;
        a5 = 6*(qf(i)-q0(i))/T^5;
        Q(:,i) = a0 + a1*t + a2*t.^2 + a3*t.^3 + a4*t.^4 + a5*t.^5;
    end
end

%% ================================
%  IPTP
% ================================
function [Q_out, t_out, T_scaled] = iptp_scale_time(Q, t, vel_max, acc_max)
    dt  = t(2) - t(1);
    dQ  = diff(Q)/dt;
    ddQ = diff(dQ)/dt;

    scale_v = max(max(abs(dQ)  ./ vel_max));
    scale_a = max(max(abs(ddQ) ./ acc_max));
    scale   = max([1, scale_v, sqrt(scale_a)]);

    if scale > 1
        T_scaled = t(end) * scale;
        t_out    = linspace(0, T_scaled, numel(t));

        Q_out = zeros(size(Q));
        q0    = Q(1,:); 
        qf    = Q(end,:);
        for i = 1:size(Q,2)
            a0 = q0(i); a1 = 0; a2 = 0;
            a3 = 10*(qf(i)-q0(i))/T_scaled^3;
            a4 = -15*(qf(i)-q0(i))/T_scaled^4;
            a5 = 6*(qf(i)-q0(i))/T_scaled^5;
            Q_out(:,i) = a0 + a1*t_out + a2*t_out.^2 + a3*t_out.^3 + ...
                         a4*t_out.^4 + a5*t_out.^5;
        end
    else
        Q_out   = Q; 
        t_out   = t; 
        T_scaled = t(end);
    end
end
